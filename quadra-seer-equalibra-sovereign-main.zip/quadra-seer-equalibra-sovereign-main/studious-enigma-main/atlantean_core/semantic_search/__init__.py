"""Semantic search package."""
